// The MIT License (MIT)

// Copyright (c) 2016 Enrico Sanino

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef APPLICATION_H_
#define APPLICATION_H_

/* Define disponibili al sistema */

#define LAMP_DATA_START_POS 0
#define LAMP_DATA_W_POS (5-1)
#define LAMP_DATA_R_POS (2-1)
#define LAMP_DATA_G_POS (3-1)
#define LAMP_DATA_B_POS (4-1)
#define LAMP_DATA_BLOCK_IFC_POS (1-1)
#define LAMP_DATA_LINT_POS (6-1)
#define LAMP_DATA_RES_0_POS (7-1)
#define LAMP_DATA_RES_1_POS (8-1)
#define LAMP_DATA_END_POS 9
#define LAMP_DATA_ADC_COLOR_SLOT 42 // the answer to everything
#define LAMP_DATA_MAX_LINT 255
#define LAMP_DATA_MAX_WHITE 255

#define LAMP_DATA_ADC_CONST 4
#define LAMP_DATA_ADC_THR 2
#define LAMP_DATA_MAX_PWM 255
//#define ADC_THR_N -4

#define LAMP_TERM_FLAG_START_CHAR 0x24 //ascii $
#define LAMP_TERM_FLAG_STOP_CHAR 0x23 //ascii #
#define LAMP_TERM_CMD_MAX_LEN 10
#define LAMP_TERM_MARKER_CHAR 0x2E // ascii .
#define LAMP_TERM_PAYLOAD_LEN (10-1)
#define LAMP_TERM_BUFF_LEN (LAMP_TERM_PAYLOAD_LEN*2)-2


#define DEBOUNCE_TIME 30
#define PRESSED 0
#define NOT_PRESSED 1

/* Assgnazione bottoni */
#define  BUTTON_MAIN 0
//#define BUTTON_INCREMENT_LIGHT 0
//#define BUTTON_DECREMENT_LIGHT 1
#define TOTAL_BUTTONS 1

// Gestione analogiche
#define VUSB 1
#define VMAIN 0

/* Tipi disponibili al sistema */


///* Stati del terminale */
//enum
//{
	//LAMP_TERM_STATE_CH_IGNORE,
	//LAMP_TERM_STATE_CH_START,
	//LAMP_TERM_STATE_CH_STOP,
	//LAMP_TERM_STATE_CH_PAYLOAD
	//};
//
///*Stati dei pulsanti utente */
//enum {
	//BUTTON_PRESSED,
	//BUTTON_STANDBY
//};


	



//
//typedef struct
//{
	//uint8_t current;
	//uint8_t assigned;
	//uint8_t assignedOld;
	//uint8_t old;
	//int8_t debounceCnt;
	//uint8_t stopPoll;
//} *BUTTON_DATA_p, LAMP_BUTTON_DATA;
//
//void lamp_interpret(uint8_t buffer[]);
//void lamp_colorSelector(uint16_t adc, uint8_t *r, uint8_t *g, uint8_t *b);
//uint8_t lamp_terminal(uint8_t ch);
//void lamp_commandTranslator();
//void lamp_intensityHandler();
//uint8_t lamp_intensityReq(void);
//void lamp_initButtons();
//uint8_t lamp_buttonAcq();
//void lamp_buttonHandler(void);
//void lamp_colorHandler();
//void lamp_autoWhiteAdj(uint8_t buffer[]);
//void lamp_powerHandler(void);
//void lamp_whiteHandler(void);
//void lamp_handler(uint8_t *hnd, uint8_t cond);


#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#define ASYNC 0
#define NO_PARITY 0
#define STOP_BIT1 0
#define DATA_8BIT 0x06
#define SYSTEM_BAUD 19200

#endif /* SYSTEM_DATA_H_ */