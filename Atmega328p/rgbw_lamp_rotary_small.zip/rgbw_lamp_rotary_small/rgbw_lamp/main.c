// The MIT License (MIT)

// Copyright (c) 2016 Enrico Sanino

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
 
#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include "rgbw_lamp.h"
enum {
    readBtn,
    uartMode,
    readEnc,
    interpret,
    apply
};
 
static unsigned char lamp_c2h(unsigned char msb);
static void spiFill(uint8_t id, uint8_t* data);
//static void lamp_handler(uint8_t *hnd, uint8_t cond);
//static void extPin1_ISR(void);
//static void lamp_interpret(uint8_t buffer[]);
//static int8_t uartRx(uint8_t buffer[]);
// USART data
static uint8_t rxComplete;
static uint8_t odd_updated = 0;
static uint16_t i;
static uint8_t rxStartLen;
static uint8_t rxBuffer[LAMP_TERM_PAYLOAD_LEN], spiBuffer[8];
//static uint8_t adc_channel;
//static uint16_t adc_data[2];
 
 
    //uint8_t busCmd;
//static    uint8_t RxBuffer[LAMP_TERM_PAYLOAD_LEN];
//static    uint8_t RxCommand[LAMP_TERM_BUFF_LEN];
 
    uint8_t btn_increment;
    uint8_t btn_decrement;
    uint8_t colorIndex;
static  uint8_t userMode;
static uint8_t state = readBtn;
static uint8_t mode = 0, lock = 0;
 
 
static unsigned char lamp_c2h(unsigned char msb){
    //if ((msb < 'a' && msb > '9') || msb < '0' || msb > 'f'{
        //// printf("Not HEX value. msb: %c, lsb: %c\n", msb, lsb);
        //return 0;
    //}
    //if (msb >= 'a' && msb <= 'f'){
        //msb = msb - 'a' + 10;
        //} else {
        //msb = msb - '0';
    //}
    //return (msb);
    //lsb=lsb&0x0F ;
    //if (lsb>'9')
    //lsb+=9;
    uint8_t tmp = 0;
    tmp = msb;
    msb=msb&0x0F ;
    if (tmp>'9')
    msb+=9;
    return (msb);
}
 
//static void lamp_handler(uint8_t *hnd, uint8_t cond)
//{
    //int16_t ovfCk = 0;
    //
    //if (sys.btn_increment!=0)
    //{
        //ovfCk = (int16_t)(*hnd + sys.btn_increment);
        //*hnd = (ovfCk > cond) ? cond : (uint8_t)ovfCk;
        //sys.btn_increment = 0;
    //}
//
    //if (sys.btn_decrement!=0)
    //{
        //ovfCk = (int16_t)(*hnd - sys.btn_decrement);
        //*hnd = (ovfCk < 0) ? 0 : (uint8_t)ovfCk;
        //sys.btn_decrement = 0;
    //}
//}
 
int main(void)
{   
    //rxBuffer[LAMP_DATA_W_POS] = 40;
    //lamp_initButtons();
    MCUCR &= ~(1 << PUD);
    //DDRD &= ~(1 << 7);
    //PORTD |= (1 << 7);
 
    //uartInitRx();
    //rxLen = 18;
    //rxStartLen = 0;
    //rxComplete = 0;
    //rxLen = 0;
    UBRR0L = (uint8_t)51;
    UBRR0H = (uint8_t)(51 >> 8);
    UCSR0C |= (ASYNC | NO_PARITY | STOP_BIT1 | DATA_8BIT); 
    UCSR0B |= (1<< TXEN0) | (1<<RXEN0) | (1<<TXCIE0) | (1<<RXCIE0);
 
	PCMSK0 = 0x02;
    PCMSK1 = 1;  /* A */  // interrupt con A PC0
    PCMSK2 = 0x10;//0x10;
    /* B */
    PCICR = 0x07; //0x06
    //OCR0A = 0;
    //TCCR0A = 0xA3;
 
    DDRD = 0b01101010; // include 
    PORTD = 0x00;
    DDRC = 0b01000000;
    PORTC = 0x00;
    DDRB = 0b00101100;
    PORTB = 0x00;
 
   // ADCSRA = 0x8f;
     
    /* Set MOSI and SCK output, all others input */
  //  DDRB = 0xff;//0b00101000;
   // PORTB = 0xff;//0b00101000;
    /* Enable SPI, Master, set clock rate fck/16 */
    SPCR = 0x53;
     
    sei();
    //DIDR0 = 0x0c;
     
    while(1)
    {

				if (rxComplete==1)
                {
                   // state = uartMode;
					 mode = 0x21;
					// state = interpret;

                }
                else
				{
					if (rxComplete == 0)
					{
						//state = readEnc;
						switch (userMode)
						{
							case 0:
							//lamp_colorHandler(&sys.colorIndex, (LAMP_DATA_ADC_COLOR_SLOT*6));
							//lamp_handler(&sys.colorIndex, (LAMP_DATA_ADC_COLOR_SLOT*6));
							//  if (btn_decrement > 0 || btn_increment > 0)
							//  {
							colorIndex = colorIndex + btn_increment - btn_decrement;
							//  }
						
						
							break;
						
							case 1:
							//lamp_intensityHandler();
							//lamp_handler(&sys.RxBuffer[LAMP_DATA_LINT_POS], LAMP_DATA_MAX_LINT);
						
							rxBuffer[LAMP_DATA_LINT_POS] = (rxBuffer[LAMP_DATA_LINT_POS] + btn_increment - btn_decrement);

							break;
						
							case 2:
							//lamp_whiteHandler();
							//lamp_handler(&sys.rxBuffer[LAMP_DATA_W_POS], LAMP_DATA_MAX_WHITE);

							rxBuffer[LAMP_DATA_W_POS] = (rxBuffer[LAMP_DATA_W_POS] + btn_increment - btn_decrement);
							if (rxBuffer[LAMP_DATA_W_POS] < 7)
								rxBuffer[LAMP_DATA_W_POS] = 0;
							break;
						}
					btn_decrement = btn_increment = 0;
					mode = 0xa4;
					//state = interpret;
					}
				}
             
           // case interpret:
             
             
            /* 30 byte SPI lib */
            /* TX -> colorIndex, R, G, B, W, Lint, MODE(usa color index o rgbw) */
            /*RX -> niente. */
             
 
            spiBuffer[0] = 0x55;
             
            spiFill(1, &rxBuffer[LAMP_DATA_LINT_POS]);
            spiFill(2, &colorIndex);
            spiFill(3, &rxBuffer[LAMP_DATA_R_POS]);
            spiFill(4, &rxBuffer[LAMP_DATA_G_POS]);
            spiFill(5, &rxBuffer[LAMP_DATA_B_POS]);
            spiFill(6, &rxBuffer[LAMP_DATA_W_POS]);
            spiFill(7, &mode);
             
             
             
            for (i = 0; i<=7; i++)
            {
                SPDR = spiBuffer[i];        
                while (!(SPSR & (1 << SPIF)))
                {
                    SPSR |= (1<<SPIF);    
                };      
            }
 
            state = readBtn;
			lock = 0;
           // break;
             
           // default:
            //break;
            //}
        }// $00.rr.gg.bb.ww.19.00.00#
    }
 
 
 
static void spiFill(uint8_t id, uint8_t* data)
    {
        if (*data == 0x55)
            (*data)++;
        spiBuffer[id] = *data;
    }
             
 
ISR(ADC_vect)
{
    //uint16_t val;
    //
    //val = ADCL>>6;
    //val |= (ADCH<<2);
    //
    //adc_data[adc_channel-2] = val;
}
 
 
 
 
ISR(USART_RX_vect)
{
     
    //colorIndex = colorIndex+3;
            rxBuffer[rxStartLen] = UDR0;
        //  tmp[j++] = rxBuffer[rxStartLen];
            //applicationSpecificUart(); // can be empty
            if (rxBuffer[rxStartLen] == LAMP_TERM_FLAG_START_CHAR)
            {
                rxStartLen = 0; //rxStartLen = rxLen; 
				odd_updated = 0;             
            }
            else if (((rxBuffer[rxStartLen] == LAMP_TERM_FLAG_STOP_CHAR)||(rxBuffer[rxStartLen] == LAMP_TERM_MARKER_CHAR)) && rxStartLen == 0)
            {
                // Ignora il carattere
                //asm("nop");
            }
            else
            {
                if (rxBuffer[rxStartLen] != LAMP_TERM_FLAG_STOP_CHAR)
                {
                    odd_updated++;
                    if (odd_updated == 2) 
                    {
                        rxBuffer[rxStartLen] = lamp_c2h(rxBuffer[rxStartLen]);
                        rxBuffer[rxStartLen-1] = lamp_c2h(rxBuffer[rxStartLen-1]);
                        rxBuffer[rxStartLen-1] = (rxBuffer[rxStartLen-1]<<4) | rxBuffer[rxStartLen];  
                        odd_updated = 0;
                        rxStartLen--;
                    }
                    rxStartLen++;
                     
                }
                else
                {
                    //rxComplete = UDR0; // dummy
                    rxComplete = 1;
                    rxStartLen = UDR0;
					rxStartLen = 0;
                }
            }
 
         
}
 
 
 
 
ISR(PCINT0_vect)
{
	
	// PB1
	
	if (!lock)
		userMode = (userMode + 1);
	lock = 1;
	if (userMode==3) userMode =0;
	
	rxComplete = 0;
} 
 
ISR(PCINT2_vect)
{
     
 
        btn_decrement = 7;
 rxComplete = 0;
}
 
ISR(PCINT1_vect)
{
 
     
        btn_increment = 7;
         rxComplete = 0;
}